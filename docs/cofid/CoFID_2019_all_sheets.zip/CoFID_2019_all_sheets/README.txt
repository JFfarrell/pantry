McCance and Widdowson's The Composition of Foods Integrated Dataset (CoFID), 2019 edition.
Converted to CSV from CoFID_2019.xlsx (one CSV per worksheet). Values unchanged from the workbook.
Official source and current (2021) edition: https://www.gov.uk/government/publications/composition-of-foods-integrated-dataset-cofid
Licence: Open Government Licence - acknowledge CoFID / Public Health England as the source.

Value codes: Tr = trace; N = present in significant quantities but no reliable figure; blank = not analysed.
All nutrient values are per 100 g edible portion. Carbohydrate is available carbohydrate as monosaccharide equivalents (excludes fibre).
The two header rows below the column names in the original workbook (component codes / short names) were dropped.
